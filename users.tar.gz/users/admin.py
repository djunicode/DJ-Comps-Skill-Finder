from django.contrib import admin
from .models import CustomUser, Skill, MentorRequest

admin.site.register(CustomUser)
admin.site.register(Skill)
admin.site.register(MentorRequest)
